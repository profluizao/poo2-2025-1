package poo2.uniderp.agencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
